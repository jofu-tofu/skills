File: passed UTF-8 read, Markdown heading/paragraph inspection and exact SHA256 source-copy equality.
Rendered: not applicable; requested plain Markdown audit has no visual requirement.
Target app: not run; delivery is Markdown audit, no app requirement. Product behavior not tested.
Adapter limitation: baseline FormatAdapters has no explicit Markdown adapter; requested format preserved.
