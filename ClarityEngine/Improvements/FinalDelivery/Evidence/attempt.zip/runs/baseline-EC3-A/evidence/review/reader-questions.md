Audience: Experienced shipping coordinators who use Shipment Review daily and understand manifests and the release queue.
1. When does the warning appear, and what does it let you do?
2. What prerequisites and access are needed, and what environment information is supplied?
3. How do Continue and Cancel differ?
4. How should you confirm both choices and their outcomes?
5. What decides whether a manifest is required, and what test or production evidence is available?
