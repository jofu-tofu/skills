# Plainness Triage

7 of 17 prose sentences are flagged. Priority adds each flag's weight: rare words and unexplained terms 3, a late main verb and a staccato kicker 2, the rest 1; a sentence is flagged at priority 2 or more. Rare means SUBTLEX-US Zipf below 3; required terms and inline code are exempt.


| ID | Section | Path | Priority | Flags | Detail | Sentence |
|---|---|---|---|---|---|---|
| s3 | Review shipments missing a manifest | main | 3 | rare words | rare: applicable | It does not determine whether the shipment requires a manifest; the coordinator still follows the applicable shipping policy. |
| s4 | Review shipments missing a manifest | main | 5 | rare words, agentless passive, vague verb | rare: workflow, editable | To try this workflow, choose an environment where this warning is enabled and open an editable pending shipment without a manifest in Shipment Review. |
| s6 | Review shipments missing a manifest | main | 3 | rare words | rare: developer | A developer console is not required. |
| s7 | Review shipments missing a manifest | main | 3 | rare words | rare: rollout | The rollout note calls this change CHANGE-472, but the note does not identify a feature flag, an environment name, or a customer deployment. |
| s8 | Review shipments missing a manifest | main | 2 | staccato kicker |  | Select Release. |
| s13 | Review shipments missing a manifest | main | 3 | rare words | rare: prerequisites | Confirm both choices using pending shipments with the same prerequisites. |
| s16 | Review shipments missing a manifest | main | 3 | rare words | rare: infer, applicable | Do not infer from the warning whether a manifest is required: that decision comes from the applicable policy, not this feature. |
