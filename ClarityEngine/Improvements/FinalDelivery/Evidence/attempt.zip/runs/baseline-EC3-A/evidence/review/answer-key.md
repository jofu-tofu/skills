1. Select Release on pending shipment without manifest; opportunity to check shipment before release queue.
2. Enabled warning environment, editable pending shipment without manifest in Shipment Review, Release access. Developer console unnecessary. CHANGE-472 names change but not flag/environment/customer deployment.
3. Continue submits to release queue without manifest. Cancel leaves pending without submitting, allowing document addition or later review.
4. Use pending shipments with same prerequisites to confirm both choices. Continue enters release queue; Cancel remains pending and not submitted.
5. Applicable shipping policy decides manifest requirement, not warning. Expected behavior only; no customer test or production result supplied.
