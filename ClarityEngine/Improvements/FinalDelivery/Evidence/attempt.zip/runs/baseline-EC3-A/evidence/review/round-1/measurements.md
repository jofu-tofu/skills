# Draft Measurements

Source: C:\Users\jzfu\Documents\Codex\2026-11-05\can-y\work\clarity-execution\runs\baseline-EC3-A\evidence\review\round-1\operator-guide-A.md

Main path: everything outside <details> blocks and appendix sections.

## Reading Time (RC-19)

| Main-path words | Minutes at 220 wpm | Range (240–200 wpm) | Budget | Status |
|---|---|---|---|---|
| 233 | 1.1 | 1.0–1.2 | 2 min (440 words) | within budget |

Collapsed or appendix words, not counted: 0.

## Headings and First Sentences (RC-5, RC-6)

| Level | Heading | First sentence |
|---|---|---|
| H1 | Review shipments missing a manifest | Shipment Review warns when a coordinator selects Release for a pending shipment with no manifest. |

## Paragraph Openings on the Main Path (RC-5)

| # | Section | First sentence |
|---|---|---|
| 1 | Review shipments missing a manifest | Shipment Review warns when a coordinator selects Release for a pending shipment with no manifest. |
| 2 | Review shipments missing a manifest | To try this workflow, choose an environment where this warning is enabled and open an editable pending shipment without a manifest in Shipment Review. |
| 3 | Review shipments missing a manifest | Select Release. |
| 4 | Review shipments missing a manifest | Confirm both choices using pending shipments with the same prerequisites. |

## Emphasized Spans (RC-10)

None found.

## First Half of the Main Path (RC-9)

117 words, ending in section "Review shipments missing a manifest". Full text: first-half.md.

## Skim Layer (RC-10)

Headings and bold text in reading order. Full text: skim-layer.md.
