# Panel
Artifact: operator-guide-A.md
SHA256: 3EE1FB3B178EB7428DD209E43830E15FEBA5B705181DE016A02B3413B53A20FB
Round: 1
Planned: Reader, Cutter, Navigator, AudienceFit.
Completed: none yet.
Intentional exclusions: Skim Reader and Logician excluded under short-form panel; Visual not applicable to plain Markdown.
Audit only; no repair authorized.
Completed: Reader; output lens-Reader.md; bytes 2095; SHA256 3EE1FB3B178EB7428DD209E43830E15FEBA5B705181DE016A02B3413B53A20FB.
Completed: Cutter; output lens-Cutter.md; bytes 2348; SHA256 3EE1FB3B178EB7428DD209E43830E15FEBA5B705181DE016A02B3413B53A20FB.
Completed: Navigator; output lens-Navigator.md; bytes 4776; SHA256 3EE1FB3B178EB7428DD209E43830E15FEBA5B705181DE016A02B3413B53A20FB.
Completed: AudienceFit; output lens-AudienceFit.md; bytes 2315; SHA256 3EE1FB3B178EB7428DD209E43830E15FEBA5B705181DE016A02B3413B53A20FB.
