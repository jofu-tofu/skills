## Why investigate now?

- The service now accepts requests from more than one source system
- This kickoff authorizes investigation only; no production improvement or problem rate has been measured.
- their user interface (UI) does not show which source system sent each one.

## What must we learn?

- Success means defining representative test cases and a measurement method for a later investigation.

## How will we gather evidence?
