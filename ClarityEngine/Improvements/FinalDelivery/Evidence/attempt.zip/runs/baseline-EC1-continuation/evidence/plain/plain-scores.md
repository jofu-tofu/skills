# Plainness Scores

3 sentences scored: 3 pick, 0 merge, 0 keep original.


## s4

- **original:** Success means defining representative test cases and a measurement method for a later investigation.
- **A:** Success means defining representative test cases and a way to measure results for a later investigation.
- **B:** Success means choosing representative test cases and deciding how to measure the work in a later investigation.
- **C:** Success means defining test cases that represent the work and deciding how to measure that work in a later investigation.

| Candidate | Gates | Rare words | Unexplained terms | Words before main verb | Mean Zipf | Agentless passives | Noun stacks | Hidden verbs | Words over 25 | Vague verbs |
|---|---|---|---|---|---|---|---|---|---|---|
| original | baseline | 1 | 0 | 1 | 4.51 | 0 | 1 | 0 | 0 | 0 |
| A | pass | 0 | 0 | 1 | 4.82 | 0 | 1 | 0 | 0 | 0 |
| B | pass | 0 | 0 | 1 | 4.91 | 0 | 0 | 0 | 0 | 0 |
| C | pass | 0 | 0 | 1 | 4.96 | 0 | 0 | 0 | 0 | 0 |

**Decision:** pick → B. B is best or tied on every major signal.

Best per signal among the original and passing candidates: Rare words: A, B, C; Unexplained terms: original, A, B, C; Words before main verb: original, A, B, C; Mean Zipf: B, C; Agentless passives: original, A, B, C; Noun stacks: B, C; Hidden verbs: original, A, B, C; Words over 25: original, A, B, C; Vague verbs: original, A, B, C.
Original's rare words: measurement. Unexplained terms: none.

## s6

- **original:** No implementation design or release decision has been approved, and a project owner and approved rollout date have not been supplied.
- **A:** No design for how to build it or release decision has been approved, and a project owner and approved launch date have not been supplied.
- **B:** No one has approved an implementation design or release decision, or supplied a project owner and an approved rollout date.
- **C:** There is no approved design for making changes or approved decision to release them, and no project owner or approved date for rolling out changes has been supplied.

| Candidate | Gates | Rare words | Unexplained terms | Words before main verb | Mean Zipf | Agentless passives | Noun stacks | Hidden verbs | Words over 25 | Vague verbs |
|---|---|---|---|---|---|---|---|---|---|---|
| original | baseline | 2 | 0 | 4 | 3.96 | 1 | 0 | 0 | 0 | 0 |
| A | pass | 0 | 0 | 5 | 4.38 | 1 | 0 | 0 | 0 | 0 |
| B | fail: numbers changed (none → 1); negation count changed (2 → 1) | 2 | 0 | 2 | 4.17 | 0 | 0 | 0 | 0 | 0 |
| C | pass | 0 | 0 | 1 | 4.64 | 1 | 0 | 0 | 3 | 0 |

**Decision:** pick → C. C is best or tied on every major signal.

Best per signal among the original and passing candidates: Rare words: A, C; Unexplained terms: original, A, C; Words before main verb: C; Mean Zipf: C; Agentless passives: original, A, C; Noun stacks: original, A, C; Hidden verbs: original, A, C; Words over 25: original, A; Vague verbs: original, A, C.
Original's rare words: implementation, rollout. Unexplained terms: none.

## s7

- **original:** Define the test cases and measurement method before drawing conclusions about production results.
- **A:** Define the test cases and how to measure results before drawing conclusions about production results.
- **B:** Define the test cases and decide how to measure results before drawing conclusions about production results.
- **C:** Define the test cases and how to measure the work before drawing conclusions about production results.

| Candidate | Gates | Rare words | Unexplained terms | Words before main verb | Mean Zipf | Agentless passives | Noun stacks | Hidden verbs | Words over 25 | Vague verbs |
|---|---|---|---|---|---|---|---|---|---|---|
| original | baseline | 1 | 0 | 0 | 4.22 | 0 | 0 | 0 | 0 | 0 |
| A | pass | 0 | 0 | 0 | 4.41 | 0 | 0 | 0 | 0 | 0 |
| B | pass | 0 | 0 | 0 | 4.44 | 0 | 0 | 0 | 0 | 0 |
| C | pass | 0 | 0 | 0 | 4.58 | 0 | 0 | 0 | 0 | 0 |

**Decision:** pick → C. C is best or tied on every major signal.

Best per signal among the original and passing candidates: Rare words: A, B, C; Unexplained terms: original, A, B, C; Words before main verb: original, A, B, C; Mean Zipf: C; Agentless passives: original, A, B, C; Noun stacks: original, A, B, C; Hidden verbs: original, A, B, C; Words over 25: original, A, B, C; Vague verbs: original, A, B, C.
Original's rare words: measurement. Unexplained terms: none.
