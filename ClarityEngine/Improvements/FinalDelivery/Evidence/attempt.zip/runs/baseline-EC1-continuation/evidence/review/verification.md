File: passed basic UTF-8 text read and Markdown heading inspection. No packaged format validation exists for this requested Markdown delivery.
Rendered: not applicable; plain Markdown artifact requested, no visual rendering requirement.
Target app: not run; delivery does not depend on a target app.
Adapter limitation: baseline FormatAdapters has no explicit Markdown adapter. Explicit user Markdown request honored without converting format.
