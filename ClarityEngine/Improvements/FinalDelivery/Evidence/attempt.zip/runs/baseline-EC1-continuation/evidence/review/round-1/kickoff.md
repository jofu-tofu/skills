## Why investigate now?

The service now accepts requests from more than one source system, so we need to understand how that affects review work. **This kickoff authorizes investigation only; no production improvement or problem rate has been measured.** Analysts see completed requests, but their UI does not show which source system sent each one.

## What must we learn?

**Success means defining representative test cases and a measurement method for a later investigation.** We need to establish how to study review work when analysts cannot see request sources. There is no approved design for making changes or approved decision to release them, and no project owner or approved date for rolling out changes has been supplied.

## How will we gather evidence?

Define the test cases and measurement method before drawing conclusions about production results. The method needs to account for the source information missing from the current UI. A future search update could expose that information, but it is not available now.

