Audience: Operations analysts with mixed expertise.
1. Why is this investigation starting now, and what production effects are known?
2. What work is authorized, and what would count as success?
3. What can analysts currently see about request sources?
4. What needs to happen next, and how does the possible search update affect that work?
5. What ownership, timing, and approval information remains unknown?
