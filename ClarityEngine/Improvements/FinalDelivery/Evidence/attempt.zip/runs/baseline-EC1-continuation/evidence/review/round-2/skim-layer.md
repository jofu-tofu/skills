## Why investigate now?

- The service now accepts requests from more than one source system, so we need to understand how that affects review work.

## What must we learn?

- Success means defining representative test cases and a measurement method for a later investigation.

## How will we gather evidence?
