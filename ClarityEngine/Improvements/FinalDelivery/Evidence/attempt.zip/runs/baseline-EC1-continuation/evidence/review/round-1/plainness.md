# Plainness Triage

3 of 9 prose sentences are flagged. Priority adds each flag's weight: rare words and unexplained terms 3, a late main verb and a staccato kicker 2, the rest 1; a sentence is flagged at priority 2 or more. Rare means SUBTLEX-US Zipf below 3; required terms and inline code are exempt.


| ID | Section | Path | Priority | Flags | Detail | Sentence |
|---|---|---|---|---|---|---|
| s4 | What must we learn? | main | 4 | rare words, noun stack | rare: measurement | Success means defining representative test cases and a measurement method for a later investigation. |
| s6 | What must we learn? | main | 2 | agentless passive, long sentence |  | There is no approved design for making changes or approved decision to release them, and no project owner or approved date for rolling out changes has been supplied. |
| s7 | How will we gather evidence? | main | 3 | rare words | rare: measurement | Define the test cases and measurement method before drawing conclusions about production results. |
