1. Service accepts requests from multiple source systems; review-work effect needs investigation. No production improvement or problem rate measured.
2. Investigation only; success is representative test cases and a measurement method for a later investigation.
3. Completed requests; UI does not reveal sending source system.
4. Define test cases and measurement method, accounting for unavailable current source information. Future search could expose sources but is unavailable now.
5. Owner and approved rollout date not supplied; no implementation design or release decision approved.
