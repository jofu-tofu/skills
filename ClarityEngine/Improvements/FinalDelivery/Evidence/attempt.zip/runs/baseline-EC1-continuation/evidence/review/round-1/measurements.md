# Draft Measurements

Source: C:\Users\jzfu\Documents\Codex\2026-11-05\can-y\work\clarity-execution\runs\baseline-EC1\evidence\review\round-1\kickoff.md

Main path: everything outside <details> blocks and appendix sections.

## Reading Time (RC-19)

| Main-path words | Minutes at 220 wpm | Range (240–200 wpm) | Budget | Status |
|---|---|---|---|---|
| 149 | 0.7 | 0.6–0.7 | 2 min (440 words) | within budget |

Collapsed or appendix words, not counted: 0.

## Headings and First Sentences (RC-5, RC-6)

| Level | Heading | First sentence |
|---|---|---|
| H2 | Why investigate now? | The service now accepts requests from more than one source system, so we need to understand how that affects review work. |
| H2 | What must we learn? | Success means defining representative test cases and a measurement method for a later investigation. |
| H2 | How will we gather evidence? | Define the test cases and measurement method before drawing conclusions about production results. |

## Paragraph Openings on the Main Path (RC-5)

| # | Section | First sentence |
|---|---|---|
| 1 | Why investigate now? | The service now accepts requests from more than one source system, so we need to understand how that affects review work. |
| 2 | What must we learn? | Success means defining representative test cases and a measurement method for a later investigation. |
| 3 | How will we gather evidence? | Define the test cases and measurement method before drawing conclusions about production results. |

## Emphasized Spans (RC-10)

| # | Section | Text |
|---|---|---|
| 1 | Why investigate now? | This kickoff authorizes investigation only; no production improvement or problem rate has been measured. |
| 2 | What must we learn? | Success means defining representative test cases and a measurement method for a later investigation. |

Bold density on the main path:

| Section | Bold words | Most spans in one paragraph |
|---|---|---|
| Why investigate now? | 27% | 1 |
| What must we learn? | 25% | 1 |

## First Half of the Main Path (RC-9)

75 words, ending in section "What must we learn?". Full text: first-half.md.

## Skim Layer (RC-10)

Headings and bold text in reading order. Full text: skim-layer.md.
