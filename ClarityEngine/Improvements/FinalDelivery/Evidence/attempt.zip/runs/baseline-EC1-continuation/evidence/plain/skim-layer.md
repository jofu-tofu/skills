## Why investigate now?

- This kickoff authorizes investigation only; no production improvement or problem rate has been measured.

## What must we learn?

- Success means defining representative test cases and a measurement method for a later investigation.

## How will we gather evidence?
