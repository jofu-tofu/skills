## Why investigate now?

The service now accepts requests from more than one source system, so we need to understand how that affects review work. This kickoff authorizes investigation only; no production improvement or problem rate has been measured. Analysts see completed requests, but their user interface (UI) does not show which source system sent each one.

## What must we learn?

Success means defining representative test cases and a measurement method for a later investigation. We need to establish how to study review work […]
