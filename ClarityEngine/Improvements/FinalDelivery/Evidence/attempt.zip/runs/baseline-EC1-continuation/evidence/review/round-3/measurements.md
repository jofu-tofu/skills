# Draft Measurements

Source: C:\Users\jzfu\Documents\Codex\2026-11-05\can-y\work\clarity-execution\runs\baseline-EC1-continuation\evidence\review\round-3\kickoff.md

Main path: everything outside <details> blocks and appendix sections.

## Reading Time (RC-19)

| Main-path words | Minutes at 220 wpm | Range (240–200 wpm) | Budget | Status |
|---|---|---|---|---|
| 157 | 0.7 | 0.7–0.8 | 2 min (440 words) | within budget |

Collapsed or appendix words, not counted: 0.

## Headings and First Sentences (RC-5, RC-6)

| Level | Heading | First sentence |
|---|---|---|
| H2 | Why investigate now? | The service now accepts requests from more than one source system, so define representative test cases and a measurement method to investigate how that affects review work. |
| H2 | What must we learn? | Success means defining representative test cases and a measurement method for a later investigation. |
| H2 | How will we gather evidence? | Define the test cases and measurement method before drawing conclusions about production results. |

## Paragraph Openings on the Main Path (RC-5)

| # | Section | First sentence |
|---|---|---|
| 1 | Why investigate now? | The service now accepts requests from more than one source system, so define representative test cases and a measurement method to investigate how that affects review work. |
| 2 | Why investigate now? | Analysts see completed requests, but their user interface (UI) does not show which source system sent each one. |
| 3 | What must we learn? | Success means defining representative test cases and a measurement method for a later investigation. |
| 4 | How will we gather evidence? | Define the test cases and measurement method before drawing conclusions about production results. |

## Emphasized Spans (RC-10)

| # | Section | Text |
|---|---|---|
| 1 | Why investigate now? | The service now accepts requests from more than one source system |
| 2 | Why investigate now? | This kickoff authorizes investigation only; no production improvement or problem rate has been measured. |
| 3 | Why investigate now? | their user interface (UI) does not show which source system sent each one. |
| 4 | What must we learn? | Success means defining representative test cases and a measurement method for a later investigation. |

Bold density on the main path:

| Section | Bold words | Most spans in one paragraph |
|---|---|---|
| Why investigate now? | 64% | 2 |
| What must we learn? | 25% | 1 |

## First Half of the Main Path (RC-9)

79 words, ending in section "What must we learn?". Full text: first-half.md.

## Skim Layer (RC-10)

Headings and bold text in reading order. Full text: skim-layer.md.

## Connective Changes (RC-25)

No sentence lost a connective.
