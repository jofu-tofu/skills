# Independent meaning check
Fresh agent ec1_meaning, no scores/strategy labels supplied.
- s4/v1: Minor scope shift. Choosing can select existing cases rather than define them; measure the work supplies a target not explicit in original.
- s4/v2: Minor scope shift. Measure results narrows to outcomes.
- s6/v1: Preserves meaning, including approvals and absent owner/date.
- s6/v2: Minor referent/scope shift. Build it introduces unspecified thing; launch could mean initial introduction.
- s7/v1: Minor scope shift. Measure the work specifies process/activity.
- s7/v2: Minor scope shift. Measure results specifies outcomes.
