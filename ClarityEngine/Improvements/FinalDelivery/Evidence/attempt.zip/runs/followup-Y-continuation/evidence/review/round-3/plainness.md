# Plainness Triage

2 of 11 prose sentences are flagged. Priority adds each flag's weight: rare words and unexplained terms 3, a late main verb and a staccato kicker 2, the rest 1; a sentence is flagged at priority 2 or more. Rare means SUBTLEX-US Zipf below 3; required terms and inline code are exempt.


| ID | Section | Path | Priority | Flags | Detail | Sentence |
|---|---|---|---|---|---|---|
| s2 | Review a shipment without a manifest | main | 3 | rare words | rare: editable | In Shipment Review, open an editable pending shipment without a manifest. |
| s5 | Review a shipment without a manifest | main | 2 | staccato kicker |  | Select Release. |
