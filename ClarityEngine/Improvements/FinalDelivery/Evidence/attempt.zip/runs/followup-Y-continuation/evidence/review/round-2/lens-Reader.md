# Reader Review
**Audience played:** A new shipping coordinator who has not used Shipment Review before.
**Input form:** extracted text

## Answers
| # | Question | Answer | Source in document |
|---|---|---|---|
| 1 | What must be true before you try this workflow, and where do you start? | In Shipment Review, open an editable pending shipment without a manifest. Have Release access and use an environment with the warning enabled. Have matching pending shipments available to check both choices. | Opening and paragraph beginning “Open an editable pending shipment”. |
| 2 | What happens when you select Release, before you choose a warning option? | The warning appears, and the shipment remains pending until I choose an option. | “Select Release. The warning appears; the shipment stays pending until you choose”. |
| 3 | What do Continue and Cancel each do, and what should you check afterward? | Continue submits the shipment to the release queue without a manifest; check that it entered the queue. Cancel leaves the shipment pending without submitting it. I read “Check both” as checking that it remains pending and was not submitted, although the phrase can also refer to testing both choices. | Continue and Cancel bullets; setup says “check both choices”. |
| 4 | How do you check both choices, and what can you do after Cancel? | Use matching pending shipments, taking Continue on one and Cancel on another. Using a separate shipment for each choice is inferred from the instruction to use matching shipments. After Cancel, add the missing document or review later. | Setup paragraph and Cancel bullet. |
| 5 | How do you decide whether a manifest is required, and are these confirmed customer test results? | Follow shipping policy. These are expected results, not confirmed customer tests. | Final paragraph. |

## Sticking Points
### Continue appears before its location — Opening
**Quote:** “In Shipment Review, Continue submits without a manifest.”
**What I was trying to find:** Where I encounter Continue in this workflow.
**What happened:** Had to look ahead to “Select Release” and the warning choices to locate Continue. The following instructions resolved this.

### Two possible meanings of both — Cancel bullet
**Quote:** “Cancel: leaves it pending without submitting it. Check both; add the missing document or review later.”
**What I was trying to find:** What to verify after choosing Cancel.
**What happened:** Had to reread. “Both” can refer to the two Cancel results (pending and not submitted), or echo “both choices” in the setup. I used the local reading for my answer but cannot rule out the other reading from the text.
