# Verified findings — round 2

## Identity and panel
All 11 SHA256 entries in panel.md match the frozen files. Artifact SHA256: C993A312FE8C179B2E90901B77A401A5C6CD33A6E6D5599B2CCC1C976951F26F. Panel completion records establish exact permitted inputs for fresh Reader, Cutter, Navigator and AudienceFit reviews. Each report is nonempty and quotes current content. No planned evidence is missing. Logician, Skim Reader and Visual are intentional exclusions. Contract absent; full revision scope applies.

## Reader scoring
Questions 1–5 are Correct against inputs/answer-key.md. Question 3 explicitly gives pending and no submission as the two Cancel checks; acknowledging the alternative meaning of “both” does not make that correct answer Partial. Its hesitation corroborates RC-20. Question 4's matching-shipment inference is supported by the artifact and matches the key. No comprehension finding is required.

## Findings adjudicated
1. AudienceFit, Cancel bullet, RC-20, Polish — VERIFIED. “Cancel: leaves it pending without submitting it. Check both; add the missing document or review later.” has a note-entry form and an ambiguous reference, independently noticed by Reader. Use a direct instruction that explicitly checks pending and no submission. Preserve “was not submitted” rather than weakening that check to only current absence from a queue. Route wording through PlainRewrite. No Major is established: Reader recovered the exact expected result.
2. Cutter, opening/Continue bullet, RC-17, Polish — VERIFIED. Both sentences state Continue submits without a manifest. Retain the complete execution instruction and preserve Shipment Review in setup if cutting the opening. Lost: no behavior or prerequisite. Coordinate with finding 3 so policy remains early.
3. Navigator, opening/closing paragraph, RC-9 and RC-26, Polish — VERIFIED. The first half and first three sentences lack the policy boundary. Move the existing policy sentence into the opening. The full Reader correctly found it; this remains a limited navigation cost.
4. Reader, opening, RC-31 considered, Polish — FALSE POSITIVE as an additional defect. “In Shipment Review, Continue submits without a manifest” introduces the control and its consequence; subsequent ordered instructions identify the warning before execution. Reader reports a nearby lookup, not an unresolved setup dependency. Navigator explicitly checked full sequential dependencies. Do not count the same introductory orientation as a new material omission.

## Repair dispositions
The earlier RC-21 Major is historical, not current evidence. Accept the refusal to invent navigation, environment or status-display facts: the brief expressly limits this revision to the supplied guide. Current AudienceFit records RC-21 PASS, and the current Reader answers the frozen execution/result questions correctly. Neither proves novice success in a live product, but the prior label alone cannot establish a current Major. No unsupported product detail is reinstated.

The prior RC-20 disposition describes an algorithm selecting original Cancel wording. That does not exempt it from current review: finding 1 remains verified at Polish. Prior RC-26 and RC-31 edits are reflected in current content; current RC-26 concerns the remaining policy placement, not a carried-over defect. No prior report is reused as current evidence.

## Conflict resolution
Cutter versus Navigator: rules 2 and 5 permit cutting the duplicate while preserving its location information in setup and moving the existing policy boundary into the opening. Keep the complete Continue step at execution. No verified answer requires two copies of the claim. These are coordinated future fixes, not changes already reviewed.

Relevance: 4/4 passed (0 out-of-scope, 0 taste, 0 downgraded)
Evidence: 3/4 verified (0 invalid, 1 false positives, 0 unneeded additions, 0 misrouted, 0 unverified)

Tally unit: three lens findings (Navigator's two checks share one finding), plus one distinct Reader sticking point; the Cancel sticking point merges into finding 1. Plainness flags are triage, not standalone findings. All verified findings are Polish. Readiness Ready; Comprehension Pass. Content not run because Logician was excluded; File passed from frozen verification; Rendered not applicable; Target app not run and not required.
