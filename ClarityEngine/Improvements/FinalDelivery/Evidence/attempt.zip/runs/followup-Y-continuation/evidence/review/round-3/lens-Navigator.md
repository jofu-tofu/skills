# Navigator Review

## Check Results
| RC | Status | Evidence |
|---|---|---|
| RC-3 | PASS | The single section, "Review a shipment without a manifest," covers prerequisites, actions, and results for one task. |
| RC-4 | N/A | The 95-word guide does not need navigation aids. |
| RC-5 | PASS | Openings are instructions ("Follow shipping policy to decide whether a manifest is required.", "In Shipment Review, open an editable pending shipment without a manifest.", "Select Release.") or a claim ("These are expected results, not confirmed customer tests."). |
| RC-6 | PASS | "Review a shipment without a manifest" predicts the task; the opening establishes its shipping-policy condition. |
| RC-8 | PASS | Prerequisites precede the action; two parallel bullets group the warning choices and their results. |
| RC-9 | PASS | The first-half extract contains the policy decision, the missing-manifest condition, access and warning prerequisites, and the instruction to select Release; branch results follow in task order. |
| RC-10 | PASS | The skim layer consistently reserves bold for interface choices (Release, Continue, Cancel), as permitted for procedural documentation; density is 3%, with at most one span per paragraph. |
| RC-23 | PASS | The title specifies the reader situation: reviewing a shipment without a manifest. |
| RC-26 | PASS | The first three sentences establish the policy boundary, the shipment to open, and the access and environment needed to act; this is an instructional document without a deadline. |
| RC-27 | N/A | The brief requests internal procedural explanation, not a decision or review artifact or an external judgment. |
| RC-31 | FAIL | "Use matching pending shipments to check both choices." refers to the choices before the document introduces the warning's Continue and Cancel branches. |

## Findings

### Introduce the choices before referring to both — Review a shipment without a manifest
**Check:** RC-31
**Severity:** Polish
**Quote:** "Use matching pending shipments to check both choices."
**Reader harm:** A new shipping coordinator must read ahead to learn which two choices the setup refers to. The following action and nearby bullets resolve the reference, so the interruption is brief.
**Fix:** Reword to "Use matching pending shipments to check Continue and Cancel in the release warning." This moves the existing choice names ahead of their first collective reference without adding behavior.
