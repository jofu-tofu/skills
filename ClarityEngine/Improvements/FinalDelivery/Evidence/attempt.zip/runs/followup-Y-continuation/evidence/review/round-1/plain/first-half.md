# Review a shipment without a manifest

In Shipment Review, Continue submits without a manifest.

Open an editable pending shipment without a manifest. You need Release access and an environment with the warning enabled. Use matching pending shipments to check both choices.

Select Release. The warning appears; the shipment stays pending until you choose:

- Choose Continue to […]
