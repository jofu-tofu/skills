# Draft Measurements

Source: C:\Users\jzfu\Documents\Codex\2026-11-05\can-y\work\clarity-execution\runs\followup-Y-continuation\artifact\operator-guide-Y.md

Main path: everything outside <details> blocks and appendix sections.

## Reading Time (RC-19)

| Main-path words | Minutes at 220 wpm | Range (240–200 wpm) | Budget | Status |
|---|---|---|---|---|
| 95 | 0.4 | 0.4–0.5 | 0.5 min (110 words) | within budget |

Collapsed or appendix words, not counted: 0.

## Headings and First Sentences (RC-5, RC-6)

| Level | Heading | First sentence |
|---|---|---|
| H1 | Review a shipment without a manifest | Follow shipping policy to decide whether a manifest is required. |

## Paragraph Openings on the Main Path (RC-5)

| # | Section | First sentence |
|---|---|---|
| 1 | Review a shipment without a manifest | Follow shipping policy to decide whether a manifest is required. |
| 2 | Review a shipment without a manifest | In Shipment Review, open an editable pending shipment without a manifest. |
| 3 | Review a shipment without a manifest | Select Release. |
| 4 | Review a shipment without a manifest | These are expected results, not confirmed customer tests. |

## Emphasized Spans (RC-10)

| # | Section | Text |
|---|---|---|
| 1 | Review a shipment without a manifest | Release |
| 2 | Review a shipment without a manifest | Continue |
| 3 | Review a shipment without a manifest | Cancel: |

Bold density on the main path:

| Section | Bold words | Most spans in one paragraph |
|---|---|---|
| Review a shipment without a manifest | 3% | 1 |

## First Half of the Main Path (RC-9)

48 words, ending in section "Review a shipment without a manifest". Full text: first-half.md.

## Skim Layer (RC-10)

Headings and bold text in reading order. Full text: skim-layer.md.

## Connective Changes (RC-25)

No sentence lost a connective.
