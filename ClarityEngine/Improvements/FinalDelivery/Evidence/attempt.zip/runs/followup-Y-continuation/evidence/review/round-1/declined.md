# Repair dispositions after round 1
- RC-21 Major: unresolved. Sole-source constraint forbids inventing missing locations/indications for queue entry, pending status and absence of submission. Requires author/product source, not stylistic editing. Keep verified finding visible.
- RC-26 Polish: bring existing Continue consequence into first paragraph; no new behavior.
- RC-31 Polish: move existing matching-shipment instruction before Release.
- RC-20 Polish: run required PlainRewrite on both quoted fragments. Continue selected as changed candidate; Cancel remained original by deterministic score. Do not override algorithm to force successful repair. Source scope unchanged; current reviewers must decide remaining effect.
No contract exists, so no contract gate is represented as run. No RC-32 cuts.
