# Plainness Scores

1 sentences scored: 0 pick, 0 merge, 1 keep original.


## cancel

- **original:** Cancel: leaves it pending without submitting it. Check both; add the missing document or review later.
- **fix:** Choose Cancel to leave the shipment pending without submitting it. Check that it stays pending and was not submitted; add the missing document or review later.
- **A:** Choose Cancel to keep the shipment pending without submitting it. Check that it is still pending and was not submitted to the release queue. Add the missing manifest or review the shipment later.
- **B:** Choose Cancel to leave the shipment pending without submitting it to the release queue. Check that the shipment is still pending and has not entered the release queue. Add the missing manifest or review the shipment later.
- **C:** Choose Cancel to leave the shipment pending without submitting it to the release queue. Check that the shipment is still pending and was not submitted to the release queue. Add the missing manifest or review the shipment later.

| Candidate | Gates | Rare words | Unexplained terms | Words before main verb | Mean Zipf | Agentless passives | Noun stacks | Hidden verbs | Words over 25 | Vague verbs |
|---|---|---|---|---|---|---|---|---|---|---|
| original | baseline | 0 | 0 | 0 | 4.81 | 0 | 0 | 0 | 0 | 0 |
| fix | fail: negation count changed (1 → 2) | 0 | 0 | 0 | 4.69 | 0 | 0 | 0 | 0 | 0 |
| A | fail: negation count changed (1 → 2) | 0 | 0 | 0 | 4.6 | 0 | 0 | 0 | 0 | 0 |
| B | fail: negation count changed (1 → 2) | 0 | 0 | 0 | 4.59 | 0 | 0 | 0 | 0 | 0 |
| C | fail: negation count changed (1 → 2) | 0 | 0 | 0 | 4.54 | 0 | 0 | 0 | 0 | 0 |

**Decision:** keep-original → original. No candidate passed the gates and beat the original.

Best per signal among the original and passing candidates: Rare words: original; Unexplained terms: original; Words before main verb: original; Mean Zipf: original; Agentless passives: original; Noun stacks: original; Hidden verbs: original; Words over 25: original; Vague verbs: original.

