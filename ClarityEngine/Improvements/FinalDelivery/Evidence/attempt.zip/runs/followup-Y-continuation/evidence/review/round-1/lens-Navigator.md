# Navigator Review

## Check Results
| RC | Status | Evidence |
|---|---|---|
| RC-3 | PASS | The single section, "Review a shipment without a manifest", has one job: perform and check the warning choices. |
| RC-4 | N/A | At 92 words with one section, the guide does not need navigation aids. |
| RC-5 | PASS | The measured openings "In Shipment Review, open an editable pending shipment without a manifest.", "Select Release.", and "Use matching pending shipments to check both choices." are actionable asks. |
| RC-6 | PASS | "Review a shipment without a manifest" predicts the task delivered by "In Shipment Review, open an editable pending shipment without a manifest." |
| RC-8 | PASS | Prerequisites, triggering action, parallel choices, and checking guidance form task-oriented groups. The short sequence is readily followed without additional headings. |
| RC-9 | PASS | The first half supplies the task, prerequisites, pending-state safeguard, and consequential choice: Continue submits to the release queue without a manifest. |
| RC-10 | PASS | The skim layer uses only interface elements: Release, Continue, and Cancel. This follows the explicit procedural-documentation exception; 3% bold density and one span per paragraph are restrained. |
| RC-23 | PASS | The title and choice list answer how to review a shipment without a manifest and what each warning choice does. |
| RC-26 | FAIL | The first three sentences give the task, prerequisites, and Release action, but not the consequence of proceeding without a manifest; that appears immediately afterward in the Continue bullet. |
| RC-27 | N/A | This internal how-to has explain intent and does not ask for a judgment or approval. |
| RC-31 | FAIL | Full sequential reading introduces the initial shipment and release action before use, but the instruction to use matching pending shipments arrives after both branch checks. |

## Findings

### Put the consequence in the opening — Review a shipment without a manifest
**Check:** RC-26
**Severity:** Polish
**Quote:** "In Shipment Review, open an editable pending shipment without a manifest. You need Release access and an environment with the warning enabled."
**Reader harm:** A new coordinator reaches the Release instruction before learning that Continue can submit the shipment without its manifest. The nearby choice bullet resolves this quickly, so the placement issue does not establish material impairment.
**Fix:** Move the existing Continue consequence into a short opening task statement, retaining the branch details below. No new product facts are needed.

### Set up the separate checks before the choices — Review a shipment without a manifest
**Check:** RC-31
**Severity:** Polish
**Quote:** "Use matching pending shipments to check both choices."
**Reader harm:** A coordinator following the guide as they read starts with one shipment and encounters both branch checks before learning that matching pending shipments are needed. The late setup can cause a brief restart after checking Continue.
**Fix:** Move this sentence before "Select Release." so the required shipments are established before either choice is exercised.
