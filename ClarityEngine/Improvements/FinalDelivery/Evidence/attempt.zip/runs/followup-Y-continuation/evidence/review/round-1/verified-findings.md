# Verified Findings — Round 1

## Identity and panel reconciliation
Recomputed SHA256 identities for operator-guide-Y.md, all six frozen input files, and all four mechanical evidence files match panel.md. All four planned reviewers completed independently with attributable, nonempty evidence against these exact inputs: Reader, Cutter, Navigator, AudienceFit. The initial “Completed: none yet” is superseded by the manifest's completion entries and final reconciliation. No evidence is reused. Audience: new shipping coordinator, novice product user without Shipment Review familiarity, internal exposure. Contract and previous declined findings are absent.

Logician, independent Skim Reader, and Visual are intentional exclusions, not missing reviewers. All five Reader answers are Correct against the matching key. There are no comprehension findings. No separate skim answers were captured or scored.

## Adjudications

### F1 — Explain how to observe the required results
- Origin: AudienceFit; RC-21; Major; VERIFIED.
- Location: Review a shipment without a manifest, choice bullets.
- Quotes: “Check that it entered the queue.” “Check both; add the missing document or review later.”
- Harm: The novice is required to verify queue entry, pending status, and no submission but receives no location or visible indication by which to perform those checks. This obstructs execution of required checks, beyond a minor wording issue.
- Named question: Where do I look, and what visible indication confirms each result?
- Evidence: Neither the current artifact nor the supplied source guide answers that question. Reader Q3 correctly identifies what to check; Q4 identifies matching shipments. Neither demonstrates how to observe the result. Thus this is not an UNNEEDED addition on the strength of those answers.
- Disposition: Preserve the Major usability finding and report the missing observation instructions as an unresolved source gap. The full edit scope permits additions, but the brief forbids invented navigation. Author may add instructions only with supporting information; no new navigation, UI labels, environment, or deployment claim is authorized by this review. Naming the gap alone does not complete the novice procedure.

### F2 — Put the consequence in the opening
- Origin: Navigator; RC-26; Polish; VERIFIED.
- Location: Review a shipment without a manifest, opening.
- Quote: “In Shipment Review, open an editable pending shipment without a manifest. You need Release access and an environment with the warning enabled.”
- Harm: The first three sentences reach Release before explaining the consequence of continuing. The nearby bullet resolves this promptly, so Polish is calibrated correctly.
- Fix: State the existing Continue consequence in the opening while preserving branch instructions. No new claim is needed. Keep interface-only bold convention.

### F3 — Set up the separate checks before the choices
- Origin: Navigator; RC-31; Polish; VERIFIED.
- Location: Review a shipment without a manifest, final paragraph.
- Quote: “Use matching pending shipments to check both choices.”
- Harm: Sequential execution introduces both branch checks before the setup needed to exercise them separately. Brief restart is plausible; material harm was not established.
- Fix: Move the quoted setup before “Select Release.” Preserve the shared prerequisites.

### F4 — Write the choice outcomes as sentences
- Origin: AudienceFit; RC-20; Polish; VERIFIED.
- Location: Review a shipment without a manifest, choice bullets.
- Quotes: “Continue: submits it to the release queue without a manifest.” “Cancel: leaves it pending without submitting it.”
- Harm: The label-plus-predicate fragments require the reader to supply the subject. Meaning is readily recovered; no material impairment is established.
- Fix: “Select **Continue** to submit the shipment to the release queue without a manifest.” “Select **Cancel** to leave the shipment pending without submitting it.” Retain the checks and Cancel follow-up.

## Filters and conflicts
All four findings are in scope, meet their owning RC and evidence standard, and have proportionate severity. No contract or prose-only restriction applies. No merge: shared locations concern distinct causes. No declined fixes exist.

The RC-21 addition is limited by factual correctness and the brief's sole-source constraint (conflict rule 2). Do not invent the missing observation details. The unresolved Major remains despite passing question scores.

Mechanical flags are triage, not additional lens findings: “editable” preserves eligibility; “Select Release.” is an imperative, not an absolute kicker. Neither corroborates the separate bullet-fragment defect or increases its severity.

Relevance: 4/4 passed (0 out-of-scope, 0 taste, 0 downgraded)
Evidence: 4/4 verified (0 invalid, 0 false positives, 0 unneeded additions, 0 misrouted, 0 unverified)

Readiness: NeedsRevision. Comprehension: Pass for the five supplied questions. Content: not run (no Logician). File: passed for frozen plain Markdown text/structure. Rendered: not applicable. Target app: not run.
