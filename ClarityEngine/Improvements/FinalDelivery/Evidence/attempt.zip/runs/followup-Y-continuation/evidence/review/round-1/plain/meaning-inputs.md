# Meaning-check inputs
Assess whether a reader takes the same meaning from each original and alternative. Report actor/action/condition/scope/cause/claim changes. No scores or strategy labels supplied.

Original context: In Shipment Review, open an editable pending shipment without a manifest. You need Release access and an environment with the warning enabled. Select Release. The warning appears; the shipment stays pending until you choose:
Original paragraph: Continue: submits it to the release queue without a manifest. Check that it entered the queue.

Final context: In Shipment Review, Continue submits without a manifest. Open an editable pending shipment without a manifest. You need Release access and an environment with the warning enabled. Use matching pending shipments to check both choices. Select Release. The warning appears; the shipment stays pending until you choose:
Alternative paragraph: Choose Continue to submit the shipment to the release queue without a manifest. Check that it entered the queue.

No qualifying runner-up. Cancel paragraph remains unchanged: Cancel: leaves it pending without submitting it. Check both; add the missing document or review later.
