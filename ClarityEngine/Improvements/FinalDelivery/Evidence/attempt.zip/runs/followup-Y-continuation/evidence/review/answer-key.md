# Answer key
1. Start in Shipment Review with editable pending shipment without manifest; Release access; warning enabled in environment. Source provides no login/navigation path or actual environment name.
2. Warning appears; shipment remains pending until a choice.
3. Continue submits to release queue without manifest; verify queue entry. Cancel leaves pending without submission; verify both pending and no submission.
4. Use matching pending shipments with same prerequisites to check each option; after Cancel add missing document or review later.
5. Follow shipping policy, not warning, for manifest requirement. Expected results only; no confirmed customer tests.
