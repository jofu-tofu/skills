# Review a shipment without a manifest

- Release
- Continue:
- Cancel:
