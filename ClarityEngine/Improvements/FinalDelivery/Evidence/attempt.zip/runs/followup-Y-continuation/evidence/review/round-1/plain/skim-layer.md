# Review a shipment without a manifest

- Continue
- Release
- Continue
- Cancel:
