# Rewrite inputs
Audience: new shipping coordinator; novice product user without Shipment Review familiarity; internal exposure.
Required terms: Shipment Review, Release, Continue, Cancel, manifest, release queue.

Rewrite only the two RC-20 sentences verified in the initial review. Triage-only s1 and s3 do not have verified RC-20 findings; no section-wide jargon finding exists. Original candidates retained in triage-candidates.json.

Context before both bullets: In Shipment Review, open an editable pending shipment without a manifest. You need Release access and an environment with the warning enabled. Select Release. The warning appears; the shipment stays pending until you choose:

Sentence continue: Continue: submits it to the release queue without a manifest.
Paragraph: Continue: submits it to the release queue without a manifest. Check that it entered the queue.
Reason: RC-20 verified Polish: label plus fragment; write a complete choice instruction.

Sentence cancel: Cancel: leaves it pending without submitting it.
Paragraph: Cancel: leaves it pending without submitting it. Check both; add the missing document or review later.
Reason: RC-20 verified Polish: label plus fragment; write a complete choice instruction.
