# Review a shipment without a manifest

In Shipment Review, open an editable pending shipment without a manifest. You need Release access and an environment with the warning enabled.

Select Release. The warning appears; the shipment stays pending until you choose:

- Continue: submits it to the release queue without a manifest. Check that […]
