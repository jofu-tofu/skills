# Rewrite inputs
Audience: new shipping coordinator; novice Shipment Review user; internal exposure.
Required terms: Shipment Review, Release, Continue, Cancel, manifest, release queue.
ID cancel: Cancel: leaves it pending without submitting it. Check both; add the missing document or review later.
Paragraph is the same complete bullet. Context: an editable pending shipment without a manifest in Shipment Review; user has Release access; warning enabled; matching pending shipments used for both choices. Select Release. Warning appears, shipment stays pending until choice. Other bullet: Choose Continue to submit the shipment to the release queue without a manifest. Check that it entered the queue.
Reason: RC-20 verified Polish: note-entry form and ambiguous both. Write direct instruction; retain explicit checks for pending and no submission and both options to add document or review later.
Use only supplied context. Keep actor, action, scope, condition, negation and UI terms. Add no product navigation or claims. Paragraph-level rewrite permitted to resolve both reference.
