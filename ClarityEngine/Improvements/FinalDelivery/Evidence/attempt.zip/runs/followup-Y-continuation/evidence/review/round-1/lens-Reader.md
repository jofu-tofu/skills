# Reader Review
**Audience played:** A new shipping coordinator who has not used Shipment Review before.
**Input form:** extracted text

## Answers
| # | Question | Answer | Source in document |
|---|---|---|---|
| 1 | What must be true before you try this workflow, and where do you start? | I need Release access, an environment with the warning enabled, and an editable pending shipment without a manifest. I start in Shipment Review and open that shipment. | Opening paragraph: “In Shipment Review, open an editable pending shipment without a manifest.” The next sentence specifies access and the enabled warning. |
| 2 | What happens when you select Release, before you choose a warning option? | The warning appears. The shipment remains pending until I choose an option. | Paragraph beginning “Select **Release**.” |
| 3 | What do Continue and Cancel each do, and what should you check afterward? | Continue submits the shipment to the release queue without a manifest; I check that it entered the queue. Cancel leaves the shipment pending without submitting it; I check that it is still pending and was not submitted. | Continue and Cancel bullets. “Check both” in the Cancel bullet refers to remaining pending and not being submitted. |
| 4 | How do you check both choices, and what can you do after Cancel? | I use matching pending shipments to check Continue and Cancel. After Cancel, I can add the missing document or review the shipment later. | Final paragraph: “Use matching pending shipments to check both choices.” Cancel bullet: “add the missing document or review later.” |
| 5 | How do you decide whether a manifest is required, and are these confirmed customer test results? | I follow shipping policy to determine whether a manifest is required. These are expected results, not confirmed customer tests. | Final two sentences. |

## Sticking Points
None recorded on the front-to-back read or the headings-and-openings reread. The supplied text answers the five questions without requiring a look ahead or reconciliation of conflicting statements. Rendered layout was not supplied.
