# Reader Review
**Audience played:** A new shipping coordinator who has not used Shipment Review before.
**Input form:** extracted text (Markdown), not rendered pages.

## Answers
| # | Question | Answer | Source in document |
|---|---|---|---|
| 1 | What must be true before you try this workflow, and where do you start? | Have Release access and an environment with the warning enabled. Start in Shipment Review with an editable pending shipment without a manifest. Use matching pending shipments for the two choices. | Opening setup paragraph: “In Shipment Review, open an editable pending shipment without a manifest.” |
| 2 | What happens when you select Release, before you choose a warning option? | The warning appears, and the shipment stays pending until you choose an option. | “Select **Release**. The warning appears; the shipment stays pending until you choose:” |
| 3 | What do Continue and Cancel each do, and what should you check afterward? | Continue submits the shipment to the release queue without a manifest; check that it entered the queue. Cancel leaves the shipment pending without submitting it; check that it is pending and has not been submitted. | Continue and Cancel bullets. |
| 4 | How do you check both choices, and what can you do after Cancel? | Use matching pending shipments, select Release, and exercise one choice on each. After Cancel, add the missing manifest or review later. | Setup: “Use matching pending shipments to check both choices.” Cancel: “Check both; add the missing document or review later.” |
| 5 | How do you decide whether a manifest is required, and are these confirmed customer test results? | Follow shipping policy to determine whether a manifest is required. These are expected results, not confirmed customer tests. | First and final paragraphs. |

## Sticking Points
### “Both” has two nearby referents — Cancel bullet
**Quote:** “**Cancel:** leaves it pending without submitting it. Check both; add the missing document or review later.”
**What I was trying to find:** What to check after Cancel.
**What happened:** Had to reread “Check both” because the setup had already used “both choices.” The immediately preceding sentence supports checking the two Cancel outcomes: pending status and no submission. I used that reading in my answer.
