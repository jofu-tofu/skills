# Navigator Review

## Check Results
| RC | Status | Evidence |
|---|---|---|
| RC-3 | PASS | “Review a shipment without a manifest” contains one task: prepare, exercise, and check the warning choices. |
| RC-4 | N/A | This 100-word guide has one section; section-jump navigation is unnecessary. |
| RC-5 | PASS | All four measured openings carry a claim or action: “In Shipment Review, Continue submits without a manifest.”; “Open an editable pending shipment without a manifest.”; “Select Release.”; “Follow shipping policy to decide whether a manifest is required.” |
| RC-6 | PASS | “Review a shipment without a manifest” predicts guidance for that task; the first sentence immediately supplies its consequential behavior. |
| RC-8 | PASS | Setup precedes the Release action, and the two parallel warning choices are grouped in bullets. |
| RC-9 | FAIL | first-half.md gives the task and Continue consequence, but omits the shipping-policy boundary that determines whether proceeding without a manifest is appropriate. |
| RC-10 | PASS | skim-layer.md uses interface names consistently; the procedural-document exception applies. Measurements show 4% bold density and at most one span per paragraph. |
| RC-23 | PASS | The title and opening identify the specific task and question: what happens when reviewing a shipment without a manifest. |
| RC-26 | FAIL | The first three sentences identify the action, pending shipment, and prerequisites, but omit the shipping-policy stakes; those appear only in the closing paragraph. |
| RC-27 | N/A | The brief specifies an internal how-to explanation, not a decision or review artifact requiring a decision block. |
| RC-31 | PASS | Full sequential reading finds setup before scenario-dependent use: the opening introduces Shipment Review, Continue, and the missing manifest; paragraph 2 introduces pending shipments, Release access, and the enabled warning; paragraph 3 introduces Release and the warning choices; the bullets introduce their respective queue and pending outcomes; the closing paragraph refers back to those expected results. No later paragraph contradicts the opening. |

## Findings

### Put the policy boundary beside the opening consequence — Review a shipment without a manifest
**Check:** RC-9, RC-26
**Severity:** Polish
**Quote:** “In Shipment Review, Continue submits without a manifest.” “Follow shipping policy to decide whether a manifest is required.”
**Reader harm:** A novice who stops after the first half sees that Continue permits submission but misses the qualification that shipping policy determines whether a manifest is required. The qualification is available nearby in this short guide, so the navigation cost is limited rather than a substantial obstruction.
**Fix:** Move the existing shipping-policy sentence immediately after the opening sentence. This brings the qualification into both the first three sentences and the first half without adding content.
