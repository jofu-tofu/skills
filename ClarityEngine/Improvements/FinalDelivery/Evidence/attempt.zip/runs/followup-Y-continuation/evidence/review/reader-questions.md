# Reader questions
Audience: a new shipping coordinator who has not used Shipment Review before.
1. What must be true before you try this workflow, and where do you start?
2. What happens when you select Release, before you choose a warning option?
3. What do Continue and Cancel each do, and what should you check afterward?
4. How do you check both choices, and what can you do after Cancel?
5. How do you decide whether a manifest is required, and are these confirmed customer test results?
