# Review a shipment without a manifest

Follow shipping policy to decide whether a manifest is required.

In Shipment Review, open an editable pending shipment without a manifest. You need Release access and an environment with the warning enabled. Use matching pending shipments to check both choices.

Select Release. The warning appears; the shipment stays […]
