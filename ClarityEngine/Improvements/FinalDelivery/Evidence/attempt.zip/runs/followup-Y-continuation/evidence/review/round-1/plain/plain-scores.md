# Plainness Scores

2 sentences scored: 1 pick, 0 merge, 1 keep original.


## continue

- **original:** Continue: submits it to the release queue without a manifest.
- **fix:** Select Continue to submit the shipment to the release queue without a manifest.
- **A:** Select Continue to submit the shipment to the release queue without a manifest.
- **B:** Select Continue to submit the shipment to the release queue without a manifest.
- **C:** Choose Continue to submit the shipment to the release queue without a manifest.

| Candidate | Gates | Rare words | Unexplained terms | Words before main verb | Mean Zipf | Agentless passives | Noun stacks | Hidden verbs | Words over 25 | Vague verbs |
|---|---|---|---|---|---|---|---|---|---|---|
| original | baseline | 0 | 0 | 1 | 3.75 | 0 | 0 | 0 | 0 | 0 |
| fix | pass | 0 | 0 | 3 | 3.71 | 0 | 0 | 0 | 0 | 0 |
| A | pass | 0 | 0 | 3 | 3.71 | 0 | 0 | 0 | 0 | 0 |
| B | pass | 0 | 0 | 3 | 3.71 | 0 | 0 | 0 | 0 | 0 |
| C | pass | 0 | 0 | 0 | 4.08 | 0 | 0 | 0 | 0 | 0 |

**Decision:** pick → C. C is best or tied on every major signal.

Best per signal among the original and passing candidates: Rare words: original, C; Unexplained terms: original, C; Words before main verb: C; Mean Zipf: C; Agentless passives: original, C; Noun stacks: original, C; Hidden verbs: original, C; Words over 25: original, C; Vague verbs: original, C.


## cancel

- **original:** Cancel: leaves it pending without submitting it.
- **fix:** Select Cancel to leave the shipment pending without submitting it.
- **A:** Select Cancel to leave the shipment pending without submitting it.
- **B:** Select Cancel to leave the shipment pending without submitting it.
- **C:** Choose Cancel to leave the shipment pending without submitting it.

| Candidate | Gates | Rare words | Unexplained terms | Words before main verb | Mean Zipf | Agentless passives | Noun stacks | Hidden verbs | Words over 25 | Vague verbs |
|---|---|---|---|---|---|---|---|---|---|---|
| original | baseline | 0 | 0 | – | 4.64 | 0 | 0 | 0 | 0 | 0 |
| fix | pass | 0 | 0 | 3 | 4.26 | 0 | 0 | 0 | 0 | 0 |
| A | pass | 0 | 0 | 3 | 4.26 | 0 | 0 | 0 | 0 | 0 |
| B | pass | 0 | 0 | 3 | 4.26 | 0 | 0 | 0 | 0 | 0 |
| C | pass | 0 | 0 | 0 | 4.48 | 0 | 0 | 0 | 0 | 0 |

**Decision:** keep-original → original. No candidate passed the gates and beat the original.

Best per signal among the original and passing candidates: Rare words: original; Unexplained terms: original; Mean Zipf: original; Agentless passives: original; Noun stacks: original; Hidden verbs: original; Words over 25: original; Vague verbs: original.

