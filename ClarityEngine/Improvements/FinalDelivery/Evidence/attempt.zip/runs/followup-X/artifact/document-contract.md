---
contract_format: 1
document: operator-guide.md
updated: 2026-11-06
---
# Document Contract

[Guide](operator-guide.md). Maintenance companion, not part of the approximately 90-word reader text.

## Roles
| Concern | Owner pass |
|---|---|
| Sections and emphasis | template |
| Product behavior, prerequisites, policy, evidence and scope | reasoning |
| Plain language and sentence structure | prose |

## Sections
### Review a shipment without a manifest
- Covers: setup, Release warning, Continue and Cancel actions and expected checks, policy boundary, expected-results caveat.
- Excludes: unsupported screen locations, invented configuration/deployment facts, developer rollout details.
- Emphasis: interface action names.

## Locks
No author-authored verbatim locks.

## Checks
| ID | Check | Owner pass | Last result |
|---|---|---|---|
| C1 | Setup states system with the warning enabled, pending shipment without manifest that user can change, and Release access | reasoning | pass |
| C2 | Continue submits without manifest; Cancel keeps pending without submission | reasoning | pass |
| C3 | Each branch states expected outcome checks | reasoning | pass |
| C4 | Shipping policy determines requirement; results are described as expected, not production-confirmed | reasoning | pass |
| C5 | A novice can locate the indicators needed to perform outcome checks using the guide alone | reasoning | fail: source lacks locations |
| C6 | Editing prerequisite uses familiar wording | prose | pass |
| C7 | Reader text stays approximately 90 words | prose | pass: 96 body words |

## Decisions
| Date | Decision | Replaces | Sweep done |
|---|---|---|---|
| 2026-11-06 | User requests shorter guide for first-time Shipment Review coordinator; preserve actions/results | Experienced audience and audit-only constraints | yes |
| 2026-11-06 | Leave source-limited navigation question unresolved; no invented product controls | none | yes |
