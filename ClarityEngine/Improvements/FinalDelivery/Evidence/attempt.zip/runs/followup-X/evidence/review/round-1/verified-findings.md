# Verified Findings — Round 1

Artifact: operator-guide.md
SHA256 independently recomputed: D9ECF256F9BA603D05A43A6D757600ACAC288A7E3A45FCB9851CA25DB7DA8E19.

## Panel reconciliation
Reader, Cutter, Navigator, and AudienceFit each supplied nonempty reports identifying this exact hash. The initial “Completed: none yet” line is superseded by the four completion entries. No planned evidence is missing. Skim Reader, Logician, and Visual are intentional exclusions. No earlier review was consulted. No contract or prior declined findings were supplied.

## Adjudication
1. **Explain how to check submission — VERIFIED, RC-21, Major.** AudienceFit quotes “Check that it entered the queue” and “Check both, then add the document or review later.” Both appear in the artifact. The named question is where the novice can observe queue entry or non-submission. Neither the guide nor its supplied original answers it. This concerns execution of both required outcome checks, not optional background. The Reader correctly identifies *what* to check; it does not answer *where*, so UNNEEDED does not apply. Major remains because the guide requires application-specific verification without giving a first-time user the means to locate it. Obtain the actual location/indicator before adding instructions; do not invent product facts. This is a content gap, not evidence of a product defect or failed live test.
2. **Use familiar wording for the editing prerequisite — VERIFIED, RC-2, Polish.** “Editable” is present and the plainness flag identifies the same wording concern. The Reader understood it; that limits severity but does not exempt unnecessary jargon. Replace with “a pending shipment you can edit.” Do not adopt the suggested wording “has the warning enabled”: the source locates enablement in the environment, not in a shipment. Preserve that distinction in any rewrite.
3. **Policy boundary unavailable to early leavers — PROPOSAL, RC-9 and RC-26, Polish.** The first half omits the policy boundary, as Navigator reports. However, moving it into the opening conflicts with the brief's explicit information_order placing policy and evidence last. Retain the order unless the author changes that requirement. The complete Reader answer is correct, so this is not a Major comprehension problem.

## Reader scoring
All five answers are Correct. No sticking points or comprehension findings. No independent Skim Reader was planned; do not infer a skim-reader pass from Navigator's interface-format check.

## Tallies
Relevance: 3/3 passed (0 out-of-scope, 0 taste, 0 downgraded)
Evidence: 2/3 verified (0 invalid, 0 false positives, 0 unneeded additions, 0 misrouted, 0 unverified)
The remaining one finding is a constraint-routed PROPOSAL, not an executable fix. Tallies count findings, not individual RC IDs.

## Verification boundaries
Content: not run under the workflow definition, because no independent Logician ran. File: passed per verification.md; current round artifact was also read and hashed. Rendered: not applicable for the requested plain Markdown source. Target app: not run and not required by this request. These exclusions do not independently block readiness; the verified RC-21 Major does.
