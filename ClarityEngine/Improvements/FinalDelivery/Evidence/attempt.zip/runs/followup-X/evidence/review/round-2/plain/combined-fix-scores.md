# Plainness Scores

1 sentences scored: 0 pick, 0 merge, 1 keep original.


## s1

- **original:** Use an environment where the warning is enabled.
- **fix:** Use a system where the warning for releasing a shipment without a manifest is enabled.
- **A:** Use a system where a warning for releasing a shipment without a manifest is enabled.
- **B:** Use a system where the warning for releasing a shipment without a manifest is enabled.
- **C:** Use a system where the warning about releasing a shipment without a manifest is enabled.

| Candidate | Gates | Rare words | Unexplained terms | Words before main verb | Mean Zipf | Agentless passives | Noun stacks | Hidden verbs | Words over 25 | Vague verbs |
|---|---|---|---|---|---|---|---|---|---|---|
| original | baseline | 0 | 0 | 0 | 4.53 | 1 | 0 | 0 | 0 | 1 |
| fix | fail: negation count changed (0 → 1) | 0 | 0 | 0 | 4.56 | 1 | 0 | 0 | 0 | 1 |
| A | fail: negation count changed (0 → 1) | 0 | 0 | 0 | 4.56 | 1 | 0 | 0 | 0 | 1 |
| B | fail: negation count changed (0 → 1) | 0 | 0 | 0 | 4.56 | 1 | 0 | 0 | 0 | 1 |
| C | fail: negation count changed (0 → 1) | 0 | 0 | 0 | 4.56 | 1 | 0 | 0 | 0 | 1 |

**Decision:** keep-original → original. No candidate passed the gates and beat the original.

Best per signal among the original and passing candidates: Rare words: original; Unexplained terms: original; Words before main verb: original; Mean Zipf: original; Agentless passives: original; Noun stacks: original; Hidden verbs: original; Words over 25: original; Vague verbs: original.

