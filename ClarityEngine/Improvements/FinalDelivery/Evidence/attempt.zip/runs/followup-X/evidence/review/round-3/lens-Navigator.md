# Navigator Review

## Check Results
| RC | Status | Evidence |
|---|---|---|
| RC-3 | PASS | One short section serves one task: review a shipment without a manifest. |
| RC-4 | N/A | A 97-word single-section guide does not need navigation aids. |
| RC-5 | PASS | All three measured openings are asks: “Use a system where the warning for releasing a shipment without a manifest is enabled.”; “Select Release to display the warning.”; “Follow shipping policy to decide whether a manifest is required.” The changed first sentence directly states a prerequisite action. |
| RC-6 | PASS | “Review a shipment without a manifest” predicts the task; its opening supplies the required warning-enabled system for that task. |
| RC-8 | PASS | Prerequisites precede Release; parallel bullets group each alternative with its confirmation. |
| RC-9 | FAIL | first-half.md reaches the warning and pending state, but neither the consequential Continue outcome nor the policy boundary appears before its cutoff. |
| RC-10 | PASS | skim-layer.md uses the procedural exception consistently: Release, Continue, and Cancel are interface elements. Measurements show 3% bold density and at most one span per paragraph. |
| RC-23 | PASS | The title identifies the task; the two alternatives answer what to do when reviewing a shipment without a manifest. |
| RC-26 | FAIL | The first three sentences specify system, shipment, and access prerequisites; they do not state the stakes or identify the expected-result evidence needed to act. |
| RC-27 | N/A | Internal action guidance, with no approval or judgment requested, does not require a decision block. |
| RC-31 | PASS | Full front-to-back reading: paragraph 1 introduces system, warning, shipment, manifest absence, Shipment Review, and access; paragraph 2 uses that shipment and warning while introducing Release and pending state. Continue introduces queue submission in its own sentence; Cancel introduces non-submission in its own sentence, with the document referring to the established manifest. The final paragraph introduces policy and qualifies the preceding expected results. No setup occurs after the event or object that depends on it. |

## Findings

### Early leavers miss the consequential choice — Review a shipment without a manifest
**Check:** RC-9
**Severity:** Polish
**Quote:** “The shipment stays pending while you decide:”
**Reader harm:** A coordinator stopping at the measured halfway point sees the safe pending state but not that Continue submits without a manifest or that policy governs the choice. Both answers occur nearby in this short guide, limiting the harm.
**Fix:** Compact the prerequisite wording enough to bring the Continue outcome into the first half; retain the brief’s required prerequisite-first order and final policy boundary.

### Opening gives prerequisites without stakes or evidence — Review a shipment without a manifest
**Check:** RC-26
**Severity:** Polish
**Quote:** “Use a system where the warning for releasing a shipment without a manifest is enabled. In Shipment Review, open a pending shipment that you can change and that has no manifest.”
**Reader harm:** The first three sentences leave the novice’s opening question—what consequence will these instructions help me check?—unanswered. The alternatives and final expected-results qualification answer it later, so this is a placement issue rather than missing information.
**Fix:** Condense the prerequisites and move an existing statement of the expected release-versus-pending outcomes into the opening; preserve the required sequence for the detailed actions.

Artifact SHA256: `83107335CC4479CC2A7194F8639422934697ECB8E708C23B06E49A09D382FE79` (`operator-guide.md`).
