1. Shipment Review, editable pending shipment without manifest, warning enabled, Release access.
2. Select Release; warning appears and shipment stays pending until choice.
3. Continue submits without manifest to release queue; check queue entry.
4. Cancel keeps pending without submission; check both; add document or review later.
5. Shipping policy decides manifest requirement; results expected, not confirmed production observations.
