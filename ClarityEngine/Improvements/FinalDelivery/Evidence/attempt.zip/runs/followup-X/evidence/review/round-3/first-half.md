# Review a shipment without a manifest

Use a system where the warning for releasing a shipment without a manifest is enabled. In Shipment Review, open a pending shipment that you can change and that has no manifest. You need Release access.

Select Release to display the warning. The shipment stays pending while you decide:

- Continue […]
