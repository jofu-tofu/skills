# Plain rewrite decisions
- s1 original: In Shipment Review, open an editable pending shipment without a manifest where the warning is enabled.
  Result: original retained. Scorer chose B, meaning checker noted access requirement becomes an if-condition and warning configuration attaches to shipment. Runner-up A also attaches warning configuration to shipment; source expressly puts warning enablement in environment. Author source check rejects this scope sharpening despite checker accepting practical paragraph equivalence. No author question: editable means capable of being edited; retained pending panel judgment.
- s2 original/result: You need Release access. Scorer retained original; no stronger passing candidate.
- s3 original: Select Release.
  Result: Select Release to display the warning. Scorer chose B; independent meaning check confirmed same UI sequence from paragraph. Removed now-duplicated warning-appearance clause, keeping pending state and choice introduction.
No sentences deferred. No unresolved factual questions. No merge needed.
