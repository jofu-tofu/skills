# Plainness Scores

1 sentences scored: 1 pick, 0 merge, 0 keep original.


## s1

- **original:** Use an environment where the warning for releasing a shipment without a manifest is enabled.
- **fix:** Use a system where the warning for releasing a shipment without a manifest is enabled.
- **A:** Use a system where a warning for releasing a shipment without a manifest is enabled.
- **B:** Use a system where the warning for releasing a shipment without a manifest is enabled.
- **C:** Use a system where the warning about releasing a shipment without a manifest is enabled.

| Candidate | Gates | Rare words | Unexplained terms | Words before main verb | Mean Zipf | Agentless passives | Noun stacks | Hidden verbs | Words over 25 | Vague verbs |
|---|---|---|---|---|---|---|---|---|---|---|
| original | baseline | 0 | 0 | 0 | 4.41 | 1 | 0 | 0 | 0 | 1 |
| fix | pass | 0 | 0 | 0 | 4.56 | 1 | 0 | 0 | 0 | 1 |
| A | pass | 0 | 0 | 0 | 4.56 | 1 | 0 | 0 | 0 | 1 |
| B | pass | 0 | 0 | 0 | 4.56 | 1 | 0 | 0 | 0 | 1 |
| C | pass | 0 | 0 | 0 | 4.56 | 1 | 0 | 0 | 0 | 1 |

**Decision:** pick → fix. fix is best or tied on every major signal.

Best per signal among the original and passing candidates: Rare words: original, fix, A, B, C; Unexplained terms: original, fix, A, B, C; Words before main verb: original, fix, A, B, C; Mean Zipf: fix, A, B, C; Agentless passives: original, fix, A, B, C; Noun stacks: original, fix, A, B, C; Hidden verbs: original, fix, A, B, C; Words over 25: original, fix, A, B, C; Vague verbs: original, fix, A, B, C.

