# Plainness Scores

3 sentences scored: 2 pick, 0 merge, 1 keep original.


## s1

- **original:** In Shipment Review, open an editable pending shipment without a manifest where the warning is enabled.
- **A:** In Shipment Review, open a pending shipment you can edit that has no manifest and has the warning turned on.
- **B:** If you have Release access, open a pending shipment in Shipment Review that you can edit, has no manifest, and has the warning turned on.
- **C:** In Shipment Review, open a pending shipment that you can edit, has no manifest, and has the warning turned on.

| Candidate | Gates | Rare words | Unexplained terms | Words before main verb | Mean Zipf | Agentless passives | Noun stacks | Hidden verbs | Words over 25 | Vague verbs |
|---|---|---|---|---|---|---|---|---|---|---|
| original | baseline | 1 | 0 | 3 | 3.91 | 1 | 0 | 0 | 0 | 1 |
| A | pass | 0 | 0 | 3 | 4.61 | 0 | 0 | 0 | 0 | 0 |
| B | pass | 0 | 0 | 0 | 4.6 | 0 | 0 | 0 | 0 | 0 |
| C | pass | 0 | 0 | 3 | 4.61 | 0 | 0 | 0 | 0 | 0 |

**Decision:** pick → B. B is best or tied on every major signal.

Best per signal among the original and passing candidates: Rare words: A, B, C; Unexplained terms: original, A, B, C; Words before main verb: B; Mean Zipf: A, B, C; Agentless passives: A, B, C; Noun stacks: original, A, B, C; Hidden verbs: original, A, B, C; Words over 25: original, A, B, C; Vague verbs: A, B, C.
Original's rare words: editable. Unexplained terms: none.

## s2

- **original:** You need Release access.
- **C:** To follow these steps, you also need Release access.

| Candidate | Gates | Rare words | Unexplained terms | Words before main verb | Mean Zipf | Agentless passives | Noun stacks | Hidden verbs | Words over 25 | Vague verbs |
|---|---|---|---|---|---|---|---|---|---|---|
| original | baseline | 0 | 0 | 1 | 5.32 | 0 | 0 | 0 | 0 | 0 |
| C | pass | 0 | 0 | 1 | 5.2 | 0 | 0 | 0 | 0 | 0 |

**Decision:** keep-original → original. No candidate passed the gates and beat the original.

Best per signal among the original and passing candidates: Rare words: original; Unexplained terms: original; Words before main verb: original; Mean Zipf: original; Agentless passives: original; Noun stacks: original; Hidden verbs: original; Words over 25: original; Vague verbs: original.


## s3

- **original:** Select Release.
- **B:** Select Release to display the warning.
- **C:** Select **Release** to display the warning.

| Candidate | Gates | Rare words | Unexplained terms | Words before main verb | Mean Zipf | Agentless passives | Noun stacks | Hidden verbs | Words over 25 | Vague verbs |
|---|---|---|---|---|---|---|---|---|---|---|
| original | baseline | 0 | 0 | – | 3.56 | 0 | 0 | 0 | 0 | 0 |
| B | pass | 0 | 0 | 3 | 4.25 | 0 | 0 | 0 | 0 | 0 |
| C | pass | 0 | 0 | 3 | 4.25 | 0 | 0 | 0 | 0 | 0 |

**Decision:** pick → B. B is best or tied on every major signal.

Best per signal among the original and passing candidates: Rare words: original, B, C; Unexplained terms: original, B, C; Words before main verb: B, C; Mean Zipf: B, C; Agentless passives: original, B, C; Noun stacks: original, B, C; Hidden verbs: original, B, C; Words over 25: original, B, C; Vague verbs: original, B, C.

