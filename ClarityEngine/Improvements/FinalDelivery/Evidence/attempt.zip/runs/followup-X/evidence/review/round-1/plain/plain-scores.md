# Plainness Scores

1 sentences scored: 1 pick, 0 merge, 0 keep original.


## s1

- **original:** In Shipment Review, open an editable pending shipment without a manifest where the warning is enabled.
- **fix:** In Shipment Review, open a pending shipment you can edit without a manifest where the warning is enabled.
- **A:** In Shipment Review, open a pending shipment you can edit that has no manifest, with the warning enabled in the environment.
- **B:** In Shipment Review, open a pending shipment that you can change and that has no manifest. Use an environment where the warning is enabled.
- **C:** In Shipment Review, open a pending shipment that you can change and that has no manifest. Use an environment where the warning is enabled.

| Candidate | Gates | Rare words | Unexplained terms | Words before main verb | Mean Zipf | Agentless passives | Noun stacks | Hidden verbs | Words over 25 | Vague verbs |
|---|---|---|---|---|---|---|---|---|---|---|
| original | baseline | 1 | 0 | 3 | 3.91 | 1 | 0 | 0 | 0 | 1 |
| fix | pass | 0 | 0 | 3 | 4.23 | 1 | 0 | 0 | 0 | 1 |
| A | pass | 0 | 0 | 3 | 4.21 | 0 | 0 | 0 | 0 | 1 |
| B | pass | 0 | 0 | 3 | 4.65 | 1 | 0 | 0 | 0 | 1 |
| C | pass | 0 | 0 | 3 | 4.65 | 1 | 0 | 0 | 0 | 1 |

**Decision:** pick → B. B is best or tied on every major signal.

Best per signal among the original and passing candidates: Rare words: fix, A, B, C; Unexplained terms: original, fix, A, B, C; Words before main verb: original, fix, A, B, C; Mean Zipf: B, C; Agentless passives: A; Noun stacks: original, fix, A, B, C; Hidden verbs: original, fix, A, B, C; Words over 25: original, fix, A, B, C; Vague verbs: original, fix, A, B, C.
Original's rare words: editable. Unexplained terms: none.
