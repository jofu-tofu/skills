# Declined / source-limited fixes
RC-21 Major cannot be safely applied: the supplied source gives no UI location/indicator for queue entry or non-submission. Original guide and current draft both lack it. Inventing locations would violate brief source-fidelity requirement. Retain verified Major and NeedsRevision; request this source detail in final status.
RC-9/RC-26 order proposal remains unapplied; it is explicitly a proposal, not verified repair. No change to shipping behavior.
