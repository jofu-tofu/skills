# Navigator Review

## Check Results
| RC | Status | Evidence |
|---|---|---|
| RC-3 | PASS | The single section, “Review a shipment without a manifest,” has one procedural job. |
| RC-4 | N/A | The artifact is a 90-word guide; section-jump navigation is unnecessary. |
| RC-5 | PASS | All three paragraph openings are action requests: “Use an environment where the warning is enabled.”; “Select Release to display the warning.”; “Follow shipping policy to decide whether a manifest is required.” |
| RC-6 | PASS | “Review a shipment without a manifest” predicts the task; “Use an environment where the warning is enabled.” starts its prerequisites. |
| RC-8 | PASS | Prerequisites precede the Release action; parallel bullets group the Continue and Cancel outcomes with their checks. |
| RC-9 | FAIL | first-half.md ends at “Continue submits it to […]”; it omits submission without a manifest and the shipping-policy boundary. |
| RC-10 | PASS | skim-layer.md contains the task heading and Release, Continue, Cancel; these consistently use the procedural interface-element convention. Measurements show 3% bold density and at most one span per paragraph. |
| RC-23 | PASS | The title identifies the specific task: reviewing a shipment without a manifest. |
| RC-26 | FAIL | The first three sentences supply prerequisites and the shipment to open, but do not state the consequence or policy stakes. |
| RC-27 | N/A | The internal action guide requests no approval or judgment on a proposal. |
| RC-31 | FAIL | The changed opening says “the warning” before identifying which warning it means. Remaining dependencies follow their setup: shipment and access precede Release; the warning and pending state precede either choice; manifest precedes “the document.” |

## Findings

### The opening assumes the warning is already identified — Review a shipment without a manifest
**Check:** RC-31
**Severity:** Polish
**Quote:** “Use an environment where the warning is enabled.”
**Reader harm:** A new coordinator must infer that this prerequisite concerns the warning for releasing a shipment without a manifest. The title and next paragraph make that inference brief, but the opening still uses a definite reference before its setup.
**Fix:** Reword to “Use an environment where the warning for releasing a shipment without a manifest is enabled.” This answers “Which warning must be enabled?”; the current guide never explicitly identifies it.

### The consequence and policy boundary arrive after the opening — Review a shipment without a manifest
**Check:** RC-9, RC-26
**Severity:** Polish
**Quote:** “Use an environment where the warning is enabled. In Shipment Review, open a pending shipment that you can change and that has no manifest.”
**Reader harm:** A coordinator who stops at the first half gets prerequisites and the Release action but misses that Continue submits without a manifest and that shipping policy governs whether this is appropriate. The full guide answers both shortly afterward, limiting the obstruction.
**Fix:** Move the existing shipping-policy boundary into the opening and make the without-manifest submission consequence visible before the halfway point, retaining prerequisites before the Release action.

<!-- Reviewed artifact SHA256: E35FD2345C9FD6AD2FAD18CA063A3425B35DC397210892C69914B9C1A94E3704 -->
