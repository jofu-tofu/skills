# Source facts retained or intentionally removed
| Source fact | Revised disposition |
|---|---|
| Warning on Release of pending shipment without manifest | Retained |
| Warning enabled, editable shipment, Release access | Retained |
| Pending until choice | Retained |
| Continue submits to release queue without manifest | Retained with outcome check |
| Cancel pending and no submission; add document/review later | Retained with outcome checks |
| Policy determines required manifest | Retained |
| Expected behavior only; no customer test/production result | Expected-results distinction retained; production unconfirmed explicit |
| CHANGE-472 label and no identified flag/environment/customer deployment | Removed under new novice/90-word request; source preserved in prior-context |
| Developer console unnecessary | Removed under novice/90-word request; no console action introduced |
| Exercise both branches with same prerequisites | Shared prerequisites plus branch-local checks retained; guide addresses acting, not developer test protocol |
