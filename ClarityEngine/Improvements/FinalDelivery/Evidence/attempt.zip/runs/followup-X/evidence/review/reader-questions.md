Audience: a new shipping coordinator who has never used Shipment Review.
1. What must be true before you start, and what do you open?
2. What action produces the warning, and what happens while you decide?
3. What does Continue do, and what should you check?
4. What does Cancel do, what should you check, and what can you do afterward?
5. How do you decide whether a manifest is required, and how certain are the described results?
