# Review a shipment without a manifest

In Shipment Review, open an editable pending shipment without a manifest where the warning is enabled. You need Release access.

Select **Release** to display the warning. The shipment stays pending while you decide:

- **Continue** submits it to the release queue without a manifest. Check that it entered the queue.
- **Cancel** leaves it pending without submission. Check both, then add the document or review later.

Follow shipping policy to decide whether a manifest is required. These are expected results, not confirmed production results.
