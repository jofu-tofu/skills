# Review a shipment without a manifest

Use an environment where the warning is enabled. In Shipment Review, open a pending shipment that you can change and that has no manifest. You need Release access.

Select Release to display the warning. The shipment stays pending while you decide:

- Continue submits it to […]
