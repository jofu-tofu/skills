# Document Brief
- topic: Investigating review work across request source systems
- audience: people who have never used request-review software
- expertise: novice; unfamiliar with source-system terminology
- audience_exposure: no prior request-review software exposure
- outcome: Understand investigation scope, current evidence limits, and the required planning outputs.
- artifact_intent: explain
- content_type: general
- key_takeaway: Define representative test cases and a measurement method; investigation alone is authorized.
- information_order: Why investigate now? establishes trigger and limits; What must we learn? establishes success and unknowns; How will we gather evidence? establishes next work and current UI constraint.
- evidence_needs: Supplied case facts only; no production measurement, owner, or rollout date supplied.
- format: Markdown, explicitly requested
- depth: overview
- budget_minutes: 2
- companion_docs: none
- required_terms: source system, UI
- constraints: Exactly the three supplied question headings. Preserve material unknowns. Do not invent research findings, ownership, implementation or release approval. No external research.

