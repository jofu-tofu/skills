New supplied source supersedes prior visibility fact: the current user interface shows source system for every completed request. Other source facts remain unchanged.
