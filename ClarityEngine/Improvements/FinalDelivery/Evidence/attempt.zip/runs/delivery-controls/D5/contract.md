Author contract: require exact visible sentence "No production measurements have been made." Existing wording is locked until author reviews proposals. No audit editing authority.
