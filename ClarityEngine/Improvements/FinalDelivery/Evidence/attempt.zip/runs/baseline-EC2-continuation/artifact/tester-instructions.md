# Test the missing-attachment warning

Check that **Submit** warns before submitting a pending request without an attachment. The warning lets you continue or cancel; it does not decide whether an attachment is required.

## Prerequisites

Use an environment with this warning turned on. You need a pending request you can change, with no attachment, and access to **Request Review** and **Submit**. No environment or request ID is supplied here.

## Check that Cancel keeps the request pending

1. Open the pending request in **Request Review** and click **Submit**.
   Expected: A warning appears because the request has no attachment.
2. Choose **Cancel**.
   Expected: The request remains pending.

## Check that Continue submits without an attachment

1. Click **Submit** again while the request is still pending and has no attachment.
   Expected: The warning appears again.
2. Choose **Continue**.
   Expected: The request is submitted without an attachment.


