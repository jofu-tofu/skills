# Draft Measurements

Source: C:\Users\jzfu\Documents\Codex\2026-11-05\can-y\work\clarity-execution\runs\baseline-EC2\artifact\tester-instructions.md

Main path: everything outside <details> blocks and appendix sections.

## Reading Time (RC-19)

| Main-path words | Minutes at 220 wpm | Range (240–200 wpm) | Budget | Status |
|---|---|---|---|---|
| 117 | 0.5 | 0.5–0.6 | 2 min (440 words) | within budget |

Collapsed or appendix words, not counted: 0.

## Headings and First Sentences (RC-5, RC-6)

| Level | Heading | First sentence |
|---|---|---|
| H1 | Test the missing-attachment warning | Check that Submit warns before submitting a pending request without an attachment. |
| H2 | Prerequisites | Use an environment with this warning turned on. |
| H2 | Check Cancel | Open the pending request in Request Review and click Submit. |
| H2 | Check Continue | Click Submit again while the request is still pending and has no attachment. |

## Paragraph Openings on the Main Path (RC-5)

| # | Section | First sentence |
|---|---|---|
| 1 | Test the missing-attachment warning | Check that Submit warns before submitting a pending request without an attachment. |
| 2 | Prerequisites | Use an environment with this warning turned on. |
| 3 | Check Cancel | Expected: A warning appears because the request has no attachment. |
| 4 | Check Cancel | Expected: The request remains pending. |
| 5 | Check Continue | Expected: The warning appears again. |
| 6 | Check Continue | Expected: The request is submitted without an attachment. |

## Emphasized Spans (RC-10)

| # | Section | Text |
|---|---|---|
| 1 | Test the missing-attachment warning | Submit |
| 2 | Prerequisites | Request Review |
| 3 | Prerequisites | Submit |
| 4 | Check Cancel | Request Review |
| 5 | Check Cancel | Submit |
| 6 | Check Cancel | Cancel |
| 7 | Check Continue | Submit |
| 8 | Check Continue | Continue |

Bold density on the main path:

| Section | Bold words | Most spans in one paragraph |
|---|---|---|
| Test the missing-attachment warning | 4% | 1 |
| Prerequisites | 9% | 2 |
| Check Cancel | 15% | 2 |
| Check Continue | 7% | 1 |

## First Half of the Main Path (RC-9)

59 words, ending in section "Prerequisites". Full text: first-half.md.

## Skim Layer (RC-10)

Headings and bold text in reading order. Full text: skim-layer.md.

## Connective Changes (RC-25)

No sentence lost a connective.
