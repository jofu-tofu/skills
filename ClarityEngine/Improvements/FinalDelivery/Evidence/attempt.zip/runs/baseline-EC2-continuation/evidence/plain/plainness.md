# Plainness Triage

5 of 13 prose sentences are flagged. Priority adds each flag's weight: rare words and unexplained terms 3, a late main verb and a staccato kicker 2, the rest 1; a sentence is flagged at priority 2 or more. Rare means SUBTLEX-US Zipf below 3; required terms and inline code are exempt.


| ID | Section | Path | Priority | Flags | Detail | Sentence |
|---|---|---|---|---|---|---|
| s3 | Prerequisites | main | 2 | agentless passive, vague verb |  | Use an environment where this warning is enabled. |
| s4 | Prerequisites | main | 3 | rare words | rare: editable | You need an editable pending request without an attachment and access to Request Review and Submit. |
| s8 | Check Cancel | main | 2 | staccato kicker |  | Choose Cancel. |
| s10 | Check Continue | main | 2 | late main verb |  | With the request still pending and without an attachment, click Submit again. |
| s12 | Check Continue | main | 2 | staccato kicker |  | Choose Continue. |
