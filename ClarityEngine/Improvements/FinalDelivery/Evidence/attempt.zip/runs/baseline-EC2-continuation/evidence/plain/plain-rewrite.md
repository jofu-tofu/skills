# Plain rewrite log
- s3: Applied A, Use an environment with this warning turned on. Meaning check passed.
- s4: Applied B, You need a pending request you can change, with no attachment, and access to Request Review and Submit. Meaning check passed.
- s8: Kept original Choose Cancel. No scored candidate beat original. The imperative is a complete UI action; no unknown term to ask author about.
- s10: Applied A, Click Submit again while the request is still pending and has no attachment. Meaning check passed.
- s12: Kept original Choose Continue. No scored candidate beat original. The imperative is a complete UI action; no unknown term to ask author about.
Originals/candidates/decisions: plain-candidates.json and plain-decisions.json.
Questions: none. Sentences deferred: zero. Merge decisions: zero.
Step 6 paragraph reread made no wording changes beyond Step 5 accepted choices. Bold UI labels preserved. No additional connective edits applied.
