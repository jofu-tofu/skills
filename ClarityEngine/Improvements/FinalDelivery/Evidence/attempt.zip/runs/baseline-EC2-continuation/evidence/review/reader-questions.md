Audience: tester who knows ordinary UI actions, not developer terminology.
1. What are you testing, and what does the warning not determine?
2. What do you need before testing?
3. How do you make the warning appear?
4. What should happen after Cancel, and how do you then test Continue?
5. What should happen after Continue?
