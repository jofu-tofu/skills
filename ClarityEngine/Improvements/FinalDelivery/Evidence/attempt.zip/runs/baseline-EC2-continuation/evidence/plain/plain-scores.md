# Plainness Scores

5 sentences scored: 3 pick, 0 merge, 2 keep original.


## s3

- **original:** Use an environment where this warning is enabled.
- **A:** Use an environment with this warning turned on.
- **B:** Use an environment that has this warning turned on.
- **C:** Use an environment set to show this warning.

| Candidate | Gates | Rare words | Unexplained terms | Words before main verb | Mean Zipf | Agentless passives | Noun stacks | Hidden verbs | Words over 25 | Vague verbs |
|---|---|---|---|---|---|---|---|---|---|---|
| original | baseline | 0 | 0 | 0 | 4.53 | 1 | 0 | 0 | 0 | 1 |
| A | pass | 0 | 0 | 0 | 5.11 | 0 | 0 | 0 | 0 | 0 |
| B | pass | 0 | 0 | 0 | 5.11 | 0 | 0 | 0 | 0 | 0 |
| C | pass | 0 | 0 | 0 | 5.2 | 0 | 0 | 0 | 0 | 0 |

**Decision:** pick → A. A is best or tied on every major signal.

Best per signal among the original and passing candidates: Rare words: original, A, B, C; Unexplained terms: original, A, B, C; Words before main verb: original, A, B, C; Mean Zipf: A, B, C; Agentless passives: A, B, C; Noun stacks: original, A, B, C; Hidden verbs: original, A, B, C; Words over 25: original, A, B, C; Vague verbs: A, B, C.


## s4

- **original:** You need an editable pending request without an attachment and access to Request Review and Submit.
- **A:** You need a pending request that you can edit and that has no attachment, plus access to Request Review and Submit.
- **B:** You need a pending request you can change, with no attachment, and access to Request Review and Submit.
- **C:** You need a pending request you can change, with no attachment, and access to Request Review and Submit.

| Candidate | Gates | Rare words | Unexplained terms | Words before main verb | Mean Zipf | Agentless passives | Noun stacks | Hidden verbs | Words over 25 | Vague verbs |
|---|---|---|---|---|---|---|---|---|---|---|
| original | baseline | 1 | 0 | 1 | 3.97 | 0 | 0 | 0 | 0 | 0 |
| A | pass | 0 | 0 | 1 | 4.34 | 0 | 0 | 0 | 0 | 0 |
| B | pass | 0 | 0 | 1 | 4.65 | 0 | 0 | 0 | 0 | 0 |
| C | pass | 0 | 0 | 1 | 4.65 | 0 | 0 | 0 | 0 | 0 |

**Decision:** pick → B. B is best or tied on every major signal.

Best per signal among the original and passing candidates: Rare words: A, B, C; Unexplained terms: original, A, B, C; Words before main verb: original, A, B, C; Mean Zipf: B, C; Agentless passives: original, A, B, C; Noun stacks: original, A, B, C; Hidden verbs: original, A, B, C; Words over 25: original, A, B, C; Vague verbs: original, A, B, C.
Original's rare words: editable. Unexplained terms: none.

## s8

- **original:** Choose Cancel.
- **A:** Click Cancel in the warning.
- **B:** Click Cancel in the warning.
- **C:** Click Cancel to leave the request pending.

| Candidate | Gates | Rare words | Unexplained terms | Words before main verb | Mean Zipf | Agentless passives | Noun stacks | Hidden verbs | Words over 25 | Vague verbs |
|---|---|---|---|---|---|---|---|---|---|---|
| original | baseline | 0 | 0 | 0 | 4.69 | 0 | 0 | 0 | 0 | 0 |
| A | pass | 0 | 0 | 0 | 4.54 | 0 | 0 | 0 | 0 | 0 |
| B | pass | 0 | 0 | 0 | 4.54 | 0 | 0 | 0 | 0 | 0 |
| C | pass | 0 | 0 | 0 | 4.6 | 0 | 0 | 0 | 0 | 0 |

**Decision:** keep-original → original. No candidate passed the gates and beat the original.

Best per signal among the original and passing candidates: Rare words: original; Unexplained terms: original; Words before main verb: original; Mean Zipf: original; Agentless passives: original; Noun stacks: original; Hidden verbs: original; Words over 25: original; Vague verbs: original.


## s10

- **original:** With the request still pending and without an attachment, click Submit again.
- **A:** Click Submit again while the request is still pending and has no attachment.
- **B:** Click Submit again while the request is still pending and has no attachment.
- **C:** Click Submit again while the request is still pending and has no attachment.

| Candidate | Gates | Rare words | Unexplained terms | Words before main verb | Mean Zipf | Agentless passives | Noun stacks | Hidden verbs | Words over 25 | Vague verbs |
|---|---|---|---|---|---|---|---|---|---|---|
| original | baseline | 0 | 0 | 9 | 3.93 | 0 | 0 | 0 | 0 | 0 |
| A | pass | 0 | 0 | 0 | 3.93 | 0 | 0 | 0 | 0 | 0 |
| B | pass | 0 | 0 | 0 | 3.93 | 0 | 0 | 0 | 0 | 0 |
| C | pass | 0 | 0 | 0 | 3.93 | 0 | 0 | 0 | 0 | 0 |

**Decision:** pick → A. A is best or tied on every major signal.

Best per signal among the original and passing candidates: Rare words: original, A, B, C; Unexplained terms: original, A, B, C; Words before main verb: A, B, C; Mean Zipf: original, A, B, C; Agentless passives: original, A, B, C; Noun stacks: original, A, B, C; Hidden verbs: original, A, B, C; Words over 25: original, A, B, C; Vague verbs: original, A, B, C.


## s12

- **original:** Choose Continue.
- **A:** Click Continue in the warning.
- **B:** Click Continue in the warning.
- **C:** Click Continue to submit the request without an attachment.

| Candidate | Gates | Rare words | Unexplained terms | Words before main verb | Mean Zipf | Agentless passives | Noun stacks | Hidden verbs | Words over 25 | Vague verbs |
|---|---|---|---|---|---|---|---|---|---|---|
| original | baseline | 0 | 0 | 0 | 4.69 | 0 | 0 | 0 | 0 | 0 |
| A | pass | 0 | 0 | 0 | 4.54 | 0 | 0 | 0 | 0 | 0 |
| B | pass | 0 | 0 | 0 | 4.54 | 0 | 0 | 0 | 0 | 0 |
| C | fail: negation count changed (0 → 1) | 0 | 0 | 0 | 3.77 | 0 | 0 | 0 | 0 | 0 |

**Decision:** keep-original → original. No candidate passed the gates and beat the original.

Best per signal among the original and passing candidates: Rare words: original; Unexplained terms: original; Words before main verb: original; Mean Zipf: original; Agentless passives: original; Noun stacks: original; Hidden verbs: original; Words over 25: original; Vague verbs: original.

