# Panel
Artifact: tester-instructions.md
SHA256: 2FD68463A577E84C2D6928392C1D93A0B7ACE2C4E7ACF8BB74B8C46969D91FE6
Round: 1
Planned: Reader, Cutter, Navigator, AudienceFit.
Completed: none yet.
Intentional exclusions: Skim Reader and Logician outside short-form panel. Visual not applicable to plain Markdown.
Completed: Reader; output lens-Reader.md; bytes 1412; SHA256 2FD68463A577E84C2D6928392C1D93A0B7ACE2C4E7ACF8BB74B8C46969D91FE6.
Completed: Cutter; output lens-Cutter.md; bytes 1127; SHA256 2FD68463A577E84C2D6928392C1D93A0B7ACE2C4E7ACF8BB74B8C46969D91FE6.
Completed: Navigator; output lens-Navigator.md; bytes 2953; SHA256 2FD68463A577E84C2D6928392C1D93A0B7ACE2C4E7ACF8BB74B8C46969D91FE6.
Completed: AudienceFit; output lens-AudienceFit.md; bytes 1054; SHA256 2FD68463A577E84C2D6928392C1D93A0B7ACE2C4E7ACF8BB74B8C46969D91FE6.
