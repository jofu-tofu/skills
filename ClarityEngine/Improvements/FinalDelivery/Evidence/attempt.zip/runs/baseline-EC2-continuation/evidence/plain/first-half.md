# Test the missing-attachment warning

Check that Submit warns before submitting a pending request without an attachment. The warning lets you continue or cancel; it does not decide whether an attachment is required.

## Prerequisites

Use an environment with this warning turned on. You need a pending request you can change, with no attachment, and access to Request Review and Submit. No environment or request ID […]
