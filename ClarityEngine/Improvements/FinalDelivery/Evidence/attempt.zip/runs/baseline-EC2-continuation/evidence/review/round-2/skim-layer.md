# Test the missing-attachment warning

- Submit

## Prerequisites

- Request Review
- Submit

## Check that Cancel keeps the request pending

- Request Review
- Submit
- Cancel

## Check that Continue submits without an attachment

- Submit
- Continue
