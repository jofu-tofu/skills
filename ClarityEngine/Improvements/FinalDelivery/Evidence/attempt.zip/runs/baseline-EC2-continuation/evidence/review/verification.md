File: passed basic UTF-8 text read and Markdown heading/list inspection. No package validator for plain Markdown.
Rendered: not applicable; plain Markdown requested.
Target app: not run; no target application required for document delivery. Product UI behavior not tested.
Adapter limitation: baseline has no explicit Markdown adapter; honoring explicit format requirement.
