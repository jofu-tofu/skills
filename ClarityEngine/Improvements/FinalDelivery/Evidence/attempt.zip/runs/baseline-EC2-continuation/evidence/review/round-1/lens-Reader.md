# Reader Review
**Audience played:** Tester who knows ordinary UI actions, not developer terminology.
**Input form:** extracted text

## Answers
| # | Question | Answer | Source in document |
|---|---|---|---|
| 1 | What are you testing, and what does the warning not determine? | Submit should warn before submitting a pending request without an attachment. The warning offers Continue or Cancel and does not determine whether an attachment is required. | Opening paragraph |
| 2 | What do you need before testing? | An environment with the warning turned on, a pending request I can change with no attachment, and access to Request Review and Submit. The document supplies no environment or request ID. | Prerequisites |
| 3 | How do you make the warning appear? | Open that pending request in Request Review and click Submit. | Check Cancel, step 1 |
| 4 | What should happen after Cancel, and how do you then test Continue? | The request should remain pending. Click Submit again while it is pending and has no attachment; the warning should appear again, then choose Continue. | Check Cancel, step 2; Check Continue, steps 1–2 |
| 5 | What should happen after Continue? | The request should be submitted without an attachment. | Check Continue, step 2 |

## Sticking Points
None in the supplied text. No forward lookup or reconciliation was needed. Rendered layout was not supplied and was not assessed.
