# Test the missing-attachment warning

Check that **Submit** warns before submitting a pending request without an attachment. The warning lets you continue or cancel; it does not decide whether an attachment is required.

## Prerequisites

Use an environment where this warning is enabled. You need an editable pending request without an attachment and access to **Request Review** and **Submit**. No environment or request ID is supplied here.

## Check Cancel

1. Open the pending request in **Request Review** and click **Submit**.
   Expected: A warning appears because the request has no attachment.
2. Choose **Cancel**.
   Expected: The request remains pending.

## Check Continue

1. With the request still pending and without an attachment, click **Submit** again.
   Expected: The warning appears again.
2. Choose **Continue**.
   Expected: The request is submitted without an attachment.
