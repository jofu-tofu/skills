1. Pending request missing attachment warns on Submit. Warning does not decide whether attachment required.
2. Environment where warning enabled, editable pending request without attachment, access Request Review and Submit. No environment or ID invented; no developer tools needed.
3. Open qualifying pending request in Request Review; click Submit.
4. Cancel keeps pending; still-pending unattached request can be submitted again to see warning and test Continue.
5. Request submits without attachment.
