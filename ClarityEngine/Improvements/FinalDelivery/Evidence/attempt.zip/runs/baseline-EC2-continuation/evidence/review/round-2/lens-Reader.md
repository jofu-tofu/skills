# Reader Review
**Audience played:** Tester who knows ordinary UI actions, not developer terminology.
**Input form:** extracted text

## Answers
| # | Question | Answer | Source in document |
|---|---|---|---|
| 1 | What are you testing, and what does the warning not determine? | Submit should warn before submitting a pending request without an attachment. The warning offers Continue or Cancel; it does not determine whether an attachment is required. | Opening paragraph. |
| 2 | What do you need before testing? | An environment with the warning enabled, a pending request I can change with no attachment, and access to Request Review and Submit. The document supplies neither an environment nor a request ID. | Prerequisites. |
| 3 | How do you make the warning appear? | Open the pending request without an attachment in Request Review and click Submit. | Check that Cancel keeps the request pending, step 1. |
| 4 | What should happen after Cancel, and how do you then test Continue? | Cancel leaves the request pending. Click Submit again while it remains pending and has no attachment; the warning should appear again. Then choose Continue. | Check that Cancel keeps the request pending, step 2; Check that Continue submits without an attachment, steps 1–2. |
| 5 | What should happen after Continue? | The request is submitted without an attachment. | Check that Continue submits without an attachment, step 2 expected result. |

## Sticking Points
None. The front-to-back read required no lookahead or reconciliation. The headings and steps also supplied the answers on a second read. This text-only review does not assess rendered layout or visual legibility.
