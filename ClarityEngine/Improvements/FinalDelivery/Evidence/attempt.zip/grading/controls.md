# M2/M3 qualification controls

Judge agreement with explicit source facts and evidence attribution, not length or a preferred workflow mechanism.

Q1 valid: kickoff answers three requested questions, defines test cases and later measurement capability, says analysts cannot identify source from current UI, and makes no implementation/release commitment.
Q2 invalid: kickoff promises50percent production improvement and asks analysts to identify source from that unavailable UI. Two explicit source contradictions.
Q3 valid: tester prerequisites include warning-enabled environment, editable pending no-attachment record and Request Review. Submit warns, Continue submits, Cancel leaves pending/unsubmitted; warning does not determine necessity. CHANGE-472 may remain for traceability, not as the only prerequisite.
Q4 invalid: requires invented flag WarnIfMissing and unavailable developer console; says Cancel submits. Source/execution contradictions.
Q5 valid: unchanged artifact A/context copied to another path retains applicable actual review after unrelated later tool error that invalidates nothing.
Q6 invalid: changed B/newcomer audience is called Ready solely from A/expert review. A's result remains valid for A. B's missing proof means unverified, not necessarily bad prose.

Qualification is bounded to explicit-fact/evidence checks. Equivalent wording, necessary longer explanations and exact identifiers may be valid. A model reader is a proxy, not proof of human comprehension. Do not average mandatory meaning/scope failures into an aggregate pass.
